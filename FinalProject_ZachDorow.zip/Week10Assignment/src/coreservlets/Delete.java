package coreservlets;

import java.sql.Connection;
import java.sql.Statement;


public class Delete {
	
	protected final static String contactTable = "contact";
	protected final static String addressTable = "address";
	protected final static String phoneTable = "phone";
	protected final static String emailAddressTable = "emailAddress";
	protected final static String employerTable = "employer";
	
	public Delete() {
	}
	
public static void DeleteContact(String id) throws Exception {
	Connection DeleteContactsConnection = Get.getConnection();
	Statement DeleteContactsStatement = DeleteContactsConnection.createStatement();
	String DeleteContactsQuery = "DELETE FROM " + contactTable + " WHERE id = " + id;
	DeleteContactsStatement.executeUpdate(DeleteContactsQuery);
}

public static void DeleteAddress(String id) throws Exception {
	Connection DeleteAddressesConnection = Get.getConnection();
	Statement DeleteAddressesStatement = DeleteAddressesConnection.createStatement();
	String DeleteAddressesQuery = "DELETE FROM " + addressTable + " WHERE contactID = " + id;
	DeleteAddressesStatement.executeUpdate(DeleteAddressesQuery);
}

public static void DeletePhoneNumber(String id) throws Exception {
	Connection DeletePhoneNumbersConnection = Get.getConnection();
	Statement DeletePhoneNumbersStatement = DeletePhoneNumbersConnection.createStatement();
	String DeletePhoneNumbersQuery = "DELETE FROM " + phoneTable + " WHERE contactID = " + id;
	DeletePhoneNumbersStatement.executeUpdate(DeletePhoneNumbersQuery);
}

public static void DeleteEmailAddresses(String id) throws Exception {
	Connection DeleteEmailAddressesConnection = Get.getConnection();
	Statement DeleteEmailAddressesStatement = DeleteEmailAddressesConnection.createStatement();
	String DeleteEmailAddressesQuery = "DELETE FROM " + emailAddressTable + " WHERE contactID = " + id;
	DeleteEmailAddressesStatement.executeUpdate(DeleteEmailAddressesQuery);
}

public static void DeleteEmployer(String id) throws Exception {
	Connection DeleteEmployerConnection = Get.getConnection();
	Statement DeleteEmployerStatement = DeleteEmployerConnection.createStatement();
	String DeleteEmployerQuery = "DELETE FROM " + employerTable + " WHERE contactID = " + id;
	DeleteEmployerStatement.executeUpdate(DeleteEmployerQuery);
}

}
