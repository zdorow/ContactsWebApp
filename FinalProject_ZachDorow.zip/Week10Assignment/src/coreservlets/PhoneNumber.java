package coreservlets;

import java.io.Serializable;

public class PhoneNumber implements Serializable {

	private static final long serialVersionUID = 3773608782961342556L;

	private int id, contactID, areaCode, exchange, extension;
	
	public PhoneNumber() {

	}
	
	public PhoneNumber(int id, int contactID, int areaCode, int exchange, int extension) {
		this.id = id;
		this.contactID = contactID;
		
		this.areaCode = areaCode;
		this.exchange = exchange;
		this.extension = extension;
	}
	
	public int getId() {
		return (id);
	}
	public int getContactID() {
		return(contactID);
	}	
	
	public int getAreaCode() {
		return (areaCode);
	}
	public int getExchange() {
		return (exchange);
	}
	public int getExtension() {
		return (extension);
	}
}
