package coreservlets;

import java.io.Serializable;

public class Address implements Serializable {

	private static final long serialVersionUID = 3773608782961342553L;
	
	private String streetAddress, state;
	private int zipCode, id, contactID;
	
	public Address() {

	}
	
	public Address(int id, int contactID, String streetAddress, String state, int zipCode) {

		this.id = id;
		this.contactID = contactID;

		this.streetAddress = streetAddress;
		this.state = state;
		this.zipCode = zipCode;
	}
	
	public int getId() {
		return (id);
	}
	public int getContactID() {
		return(contactID);
	}
	
	public String getStreetAddress() {
		return (streetAddress);
	}

	public int getZipCode() {
		return (zipCode);
	}
	public String getState() {
		return (state);
	}
}
