package coreservlets;

import org.apache.commons.validator.routines.EmailValidator;

public class Validation {

//Validating Contact information is not null or blank
	
	public static Boolean isContactValid(String firstName, String middleName, String lastName) {
		if (firstName == null || middleName == null || lastName == null
			|| firstName.trim().equals("") || middleName.trim().equals("") || lastName.trim().equals(""))
		{
			return false;
			}
		else
			return true;	
		}

//Validating Address and zip code is all numbers the rest if it is not blank or null
	
	public static Boolean isAddressValid(String streetAddress, String state, String zipCode) {
		System.out.println(isAllNumbers(zipCode));
		if (streetAddress == null || state == null || zipCode == null
			|| streetAddress.trim().equals("") || state.trim().equals("") || zipCode.trim().equals("") || !isAllNumbers(zipCode))
		{			
			return false;
			}
		else
			return true;
		}
	
//Validating the phone numbers all have the correct number of digits and are all numbers
	
	public static Boolean isPhoneNumberValid(String areaCode, String exchange, String extension) {

		if (areaCode.length() != 3 || exchange.length() != 3 || extension.length() != 4
				|| !isAllNumbers(areaCode) || !isAllNumbers(exchange) || !isAllNumbers(extension))
			{
			return false;
			}
		else
			return true;
		}
	
//Validating Email address using Apache library
	
	public static Boolean isEmailAddressValid(String emailAddress) {
		
		if(EmailValidator.getInstance().isValid(emailAddress))
		{
		return true;
		}
		else
		return false;
		}
	
//Validating Employer ensuring zip code is all numbers and the rest are not null
	
	public static Boolean isEmployerValid(String companyName, String streetAddress, String state, String zipCode) {
		if (companyName == null || streetAddress == null || state == null || zipCode == null
				|| companyName.trim().equals("") || streetAddress.trim().equals("") || state.trim().equals("") || zipCode.trim().equals("")
				|| !isAllNumbers(zipCode))
			{
			return false;
			}
		else
			return true;
		}
	
//Validating if the entry is all numbers
	
	public static Boolean isAllNumbers(String string) {
		return string.matches("^[-+]?\\d+(\\.\\d+)?$");
	}
}
