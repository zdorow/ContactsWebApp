package coreservlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import coreservlets.Add;
import coreservlets.Validation;

/**
 * Servlet implementation class AddController for adding the elements of a contact to the database
 */
@WebServlet("/AddController")
public class AddController extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public AddController() {
        super();

    }
    
    // POST only servlet 
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id = request.getParameter("id");		

		
		Boolean AddContact = Boolean.parseBoolean(request.getParameter("AddContact"));		
		Boolean AddAddress = Boolean.parseBoolean(request.getParameter("AddAddress"));
		Boolean AddNumber = Boolean.parseBoolean(request.getParameter("AddNumber"));
		Boolean AddEmailAddress = Boolean.parseBoolean(request.getParameter("AddEmailAddress"));		
		Boolean AddEmployer = Boolean.parseBoolean(request.getParameter("AddEmployer"));
		Boolean Complete = Boolean.parseBoolean(request.getParameter("Complete"));
		
		Boolean AddDone = Boolean.parseBoolean(request.getParameter("AddDone"));
		
//Add Logic if any of these is send as true it will pass on to direction login
if(AddContact || AddAddress || AddNumber || AddEmailAddress || AddEmployer || AddDone) {
			request.setAttribute("id", id);
			
		//If adding the contact is complete then we validate and move to success page 
			
		if (AddContact && Complete){
			String firstName = request.getParameter("firstName");
			String middleName = request.getParameter("middleName");
			String lastName = request.getParameter("lastName"); 
			 
			if(Validation.isContactValid(firstName, middleName, lastName))
			{
				try {
					int ID = Add.AddContact(firstName, middleName, lastName);
					request.setAttribute("id", ID);
				} catch (Exception e) {
					System.out.println("Error Adding Contact");
					e.printStackTrace();
				}
		    	RequestDispatcher dispatcher = request.getRequestDispatcher("/AddSuccess.jsp");
		        dispatcher.forward(request, response);
			}
			else {
				request.setAttribute("Invalid", "Invalid Entry");
				request.setAttribute("firstName", firstName);
				request.setAttribute("middleName", middleName);
				request.setAttribute("lastName", lastName);
		    	RequestDispatcher dispatcher = request.getRequestDispatcher("/AddContact.jsp");
		        dispatcher.forward(request, response);
			}
			
			}
		
		//Initial Contact add page
		
		else if (AddContact){
			RequestDispatcher dispatcher = request.getRequestDispatcher("/AddContact.jsp");
		    dispatcher.forward(request, response);
		}
		
		// Validation of address entry and passed to success if valid
		
		else if (AddAddress && Complete){			
			String streetAddress = request.getParameter("streetAddress");
			String state = request.getParameter("state");
			String zipCode = request.getParameter("zipCode"); 
			
			if (Validation.isAddressValid(streetAddress, state, zipCode))
			{
			try {
				int cID = Integer.parseInt(id);
				int zip = Integer.parseInt(zipCode);
				Add.AddAddress(cID, streetAddress, state, zip);
				
			} catch (Exception e) {
				System.out.println("Error Adding Street Address");
				e.printStackTrace();
			}
			request.setAttribute("Add", "Address");
			RequestDispatcher dispatcher = request.getRequestDispatcher("/AddSuccess.jsp");
		        dispatcher.forward(request, response);
			}
			else {
				request.setAttribute("Invalid", "Invalid Entry");
				request.setAttribute("streetAddress", streetAddress);
				request.setAttribute("state",  state);
				request.setAttribute("zipCode", zipCode);
		    	RequestDispatcher dispatcher = request.getRequestDispatcher("/AddAddress.jsp");
		        dispatcher.forward(request, response);
			}
		    }
		
		//Initial Address page
		
		else if (AddAddress){
			RequestDispatcher dispatcher = request.getRequestDispatcher("/AddAddress.jsp");
		    dispatcher.forward(request, response);
		}
		
		//When phone number is complete it is validated and the passed to success if valid
		
		else if (AddNumber && Complete){
			String areaCode = request.getParameter("areaCode");
			String exchange = request.getParameter("exchange");
			String extension = request.getParameter("extension");
			
			if (Validation.isPhoneNumberValid(areaCode, exchange, extension))
			{
			try {
				int cID = Integer.parseInt(id);
				int AC = Integer.parseInt(areaCode);
				int ex = Integer.parseInt(exchange);
				int ext = Integer.parseInt(extension);
				Add.AddPhoneNumber(cID, AC, ex, ext);
				
			} catch (Exception e) {
				System.out.println("Error Adding Phone Number");
				e.printStackTrace();
			}
			request.setAttribute("Add", "Phone Number");
			RequestDispatcher dispatcher = request.getRequestDispatcher("/AddSuccess.jsp");
		        dispatcher.forward(request, response);
			}
			else {
				request.setAttribute("Invalid", "Invalid Entry");
				request.setAttribute("areaCode", areaCode);
				request.setAttribute("exchange", exchange);
				request.setAttribute("extension", extension);
				
		    	RequestDispatcher dispatcher = request.getRequestDispatcher("/AddPhoneNumber.jsp");
		        dispatcher.forward(request, response);
			}
		        }
		
		//Initial Phone Number add page
		
		else if (AddNumber){
		        	RequestDispatcher dispatcher = request.getRequestDispatcher("/AddPhoneNumber.jsp");
		            dispatcher.forward(request, response);
		        }
		
		//When adding Email Address is completed it is validated and directed for success page 
		
		else if (AddEmailAddress && Complete){
			String emailAddress = request.getParameter("emailAddress");
			
			if (Validation.isEmailAddressValid(emailAddress))
			{
			try {
				int cID = Integer.parseInt(id);
				
				Add.AddEmailAddresses(cID, emailAddress);
				
			} catch (Exception e) {
				System.out.println("Invalid Adding Email Address");
				e.printStackTrace();
			}
			request.setAttribute("Add", "Email Address");
			RequestDispatcher dispatcher = request.getRequestDispatcher("/AddSuccess.jsp");
		        dispatcher.forward(request, response);
			}
			else {
				request.setAttribute("Invalid", "Invalid Entry");
				request.setAttribute("emailAddress", emailAddress);
				
		    	RequestDispatcher dispatcher = request.getRequestDispatcher("/AddEmailAddress.jsp");
		        dispatcher.forward(request, response);

		        }
		}
		
		//Initial Email address add is selected
		
		else if (AddEmailAddress){
		        	RequestDispatcher dispatcher = request.getRequestDispatcher("/AddEmailAddress.jsp");
		            dispatcher.forward(request, response);
		        }
		
		//When adding employer is completed it is validated and directed for success page 
		
		else if (AddEmployer && Complete){
			String employer = request.getParameter("employer");
			String employerStreetAddress = request.getParameter("employerStreetAddress");
			String employerState = request.getParameter("employerState");
			String employerZipCode = request.getParameter("employerZipCode");
			
			if (Validation.isEmployerValid(employer, employerStreetAddress, employerState, employerZipCode))
			{
			try {
				int cID = Integer.parseInt(id);
				int zip = Integer.parseInt(employerZipCode);
				Add.AddEmployer(cID, employer, employerStreetAddress, employerState, zip);
				
			} catch (Exception e) {
				System.out.println("Error Adding Employer");
				e.printStackTrace();
			}
			request.setAttribute("Add", "Employer");
			RequestDispatcher dispatcher = request.getRequestDispatcher("/AddSuccess.jsp");
		        dispatcher.forward(request, response);
			}
			else {
				request.setAttribute("Invalid", "Invalid Entry");
				request.setAttribute("employer", employer);
				request.setAttribute("employerStreetAddress", employerStreetAddress);
				request.setAttribute("employerState", employerState);
				request.setAttribute("employerZipCode", employerZipCode);
				
		    	RequestDispatcher dispatcher = request.getRequestDispatcher("/AddEmployer.jsp");
		        dispatcher.forward(request, response);

		        }
        }

		// Initial page for adding an employer
		
		else if (AddEmployer){
		            	RequestDispatcher dispatcher = request.getRequestDispatcher("/AddEmployer.jsp");
		                dispatcher.forward(request, response);
		            }
		
// Logic for ADD ALL page
		
		else{
			
			String firstName = request.getParameter("firstName");
			String middleName = request.getParameter("middleName");
			String lastName = request.getParameter("lastName");
			
			String streetAddress = request.getParameter("streetAddress");
			String state = request.getParameter("state");
			String zipCode = request.getParameter("zipCode");
			
			String areaCode = request.getParameter("areaCode");
			String exchange = request.getParameter("exchange");
			String extension = request.getParameter("extension");
			
			String emailAddress = request.getParameter("emailAddress");
			
			String employer = request.getParameter("employer");
			String employerStreetAddress = request.getParameter("employerStreetAddress");
			String employerState = request.getParameter("employerState");
			String employerZipCode = request.getParameter("employerZipCode");
			
			if(Validation.isContactValid(firstName, middleName, lastName) && Validation.isAddressValid(streetAddress, state, zipCode)
					&& Validation.isPhoneNumberValid(areaCode, exchange, extension) && Validation.isEmailAddressValid(emailAddress)
					&& Validation.isEmployerValid(employer, employerStreetAddress, employerState, employerZipCode))
			{
				try {
			int ID = Add.AddContact(firstName, middleName, lastName);
			
			int zip = Integer.parseInt(zipCode);
			Add.AddAddress(ID, streetAddress, state, zip);
			
			int aC = Integer.parseInt(areaCode);
			int ex = Integer.parseInt(exchange);
			int ext = Integer.parseInt(extension);
			Add.AddPhoneNumber(ID, aC, ex, ext);
			
			Add.AddEmailAddresses(ID, emailAddress);	
			
			int eZip = Integer.parseInt(employerZipCode);
			Add.AddEmployer(ID, employer, employerStreetAddress, employerState, eZip);
			
			request.setAttribute("id", ID);
			
			} catch (Exception e) {
				System.out.println("Error Adding Contact" + e);
				e.printStackTrace();
			}
				RequestDispatcher dispatcher = request.getRequestDispatcher("/AddSuccess.jsp");
		        dispatcher.forward(request, response);
		            }
			else {
				request.setAttribute("Invalid", "Invalid Entry");
				request.setAttribute("firstName", firstName);
				request.setAttribute("middleName", middleName);
				request.setAttribute("lastName", lastName);
				
				request.setAttribute("streetAddress", streetAddress);
				request.setAttribute("state",  state);
				request.setAttribute("zipCode", zipCode);
				
				request.setAttribute("areaCode", areaCode);
				request.setAttribute("exchange", exchange);
				request.setAttribute("extension", extension);
				
				request.setAttribute("emailAddress", emailAddress);
				
				request.setAttribute("employer", employer);
				request.setAttribute("employerStreetAddress", employerStreetAddress);
				request.setAttribute("employerState", employerState);
				request.setAttribute("employerZipCode", employerZipCode);
				
		    	RequestDispatcher dispatcher = request.getRequestDispatcher("/AddAll.jsp");
		        dispatcher.forward(request, response);

		        }
			}
}
// Main if end

// Trailing else
else{
	request.setAttribute("id", id);
		   RequestDispatcher dispatcher = request.getRequestDispatcher("/AddAll.jsp");
		   dispatcher.forward(request, response);
		                }
	}

}
