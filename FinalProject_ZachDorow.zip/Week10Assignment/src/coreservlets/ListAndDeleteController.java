package coreservlets;

import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

/**
* List and delete controller since we have Get and post I figured they went well together
 */

@WebServlet("/ListAndDeleteController")
public class ListAndDeleteController extends HttpServlet {

	private static final long serialVersionUID = 1L;
	
	protected final String dbName = "myDatabase";
	protected final String url = "jdbc:derby:" + dbName;
	protected final String contactTable = "contact";
	protected final String addressTable = "address";
	protected final String phoneTable = "phone";
	protected final String emailAddressTable = "emailAddress";
	protected final String employerTable = "employer";
	protected final String username = "someuser";
	protected final String password = "somepassword";
	

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

//Setting up contact list page		
		String id = request.getParameter("id");
		String contactID = id;
		
		if (id == null || id == "0")
		{
			try {		
				List<Contact> ContactList = Get.GetContactList(contactID);
				request.setAttribute("ContactList", ContactList);	
				
			} catch (Exception e) {
				System.err.println("Error Gathering Table: " + e);
				}
			RequestDispatcher dispatcher = request.getRequestDispatcher("/EmployeeList.jsp");
		    dispatcher.forward(request, response);
		}
		else
		{
			try {
//Contact Request 					
				List<Contact> ContactDetail = Get.GetContactDetail(contactID);
				request.setAttribute("ContactDetail", ContactDetail);

//Address Request				
				List<Address> AddressDetail = Get.GetAddressDetail(contactID);
				request.setAttribute("AddressDetail", AddressDetail);
				
//Phone Number Request
				List<PhoneNumber> phoneNumberDetail = Get.GetPhoneNumberDetail(contactID);
				request.setAttribute("phoneNumberDetail", phoneNumberDetail);
				
//Email Address Request
				List<EmailAddress> emailAddressDetail = Get.GetEmailAddressDetail(contactID);
				request.setAttribute("emailAddressDetail", emailAddressDetail);
				
//Employer Request	
				List<Employer> employerDetail = Get.GetEmployerDetail(contactID);
				request.setAttribute("employerDetail", employerDetail);
				
			} catch (Exception e) {
				System.err.println("Error Looking up contactID: " + contactID + e);
				}
			
			RequestDispatcher dispatcher = request.getRequestDispatcher("/EmployeeDetails.jsp");
			dispatcher.forward(request, response);		
	    }	
}
		
	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id = request.getParameter("id");
		request.setAttribute("id", id);
		
		Boolean DeleteAll = Boolean.parseBoolean(request.getParameter("Delete"));
		Boolean DeleteAddress = Boolean.parseBoolean(request.getParameter("DeleteAddress"));
		Boolean DeletePhoneNumber = Boolean.parseBoolean(request.getParameter("DeletePhoneNumber"));
		Boolean DeleteEmailAddresses = Boolean.parseBoolean(request.getParameter("DeleteEmailAddresses"));
		Boolean DeleteEmployer = Boolean.parseBoolean(request.getParameter("DeleteEmployer"));  		
		
if 	(DeleteAll || DeleteAddress || DeletePhoneNumber || DeleteEmailAddresses || DeleteEmployer) {		
		System.out.println(DeleteAll + id);
		
		try {
//Delete Contacts
			if (DeleteAll) {		
				Delete.DeleteContact(id);
				request.setAttribute("Deletion", "Contact");
}			
//Delete Addresses
			else if (DeleteAll || DeleteAddress) {
				Delete.DeleteAddress(id);
				request.setAttribute("Deletion", "Addresseses ");
}			
//Delete Phone Numbers
			else if (DeleteAll || DeletePhoneNumber) {
				Delete.DeletePhoneNumber(id);
				request.setAttribute("Deletion", "Phone Numbers ");
}			
//Delete Email Address
			else if (DeleteAll || DeleteEmailAddresses) {
				Delete.DeleteEmailAddresses(id);
				request.setAttribute("Deletion", "Email Addresses ");
}			
//Delete Employer
			else if (DeleteAll || DeleteEmployer) {			
				Delete.DeleteEmployer(id);
				request.setAttribute("Deletion", "Employers ");
}			
		} catch (Exception e) {
			System.err.println("Error Deleting Entry" + e );
			e.printStackTrace();
		}
		RequestDispatcher dispatcher = request.getRequestDispatcher("/DeleteSuccess.jsp");
	    dispatcher.forward(request, response);
	
}

//Trailing else for failover
else{
            	RequestDispatcher dispatcher = request.getRequestDispatcher("/EmployeeList.jsp");
                dispatcher.forward(request, response);
            }
	}

}
