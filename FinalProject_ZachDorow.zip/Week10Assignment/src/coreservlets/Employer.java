package coreservlets;

import java.io.Serializable;

public class Employer implements Serializable {

	private static final long serialVersionUID = 3773608782961342554L;
	
	private String companyName, streetAddress, state;
	private int zipCode, id, contactID;
	
	public Employer() {

	}
	
	public Employer(int id, int contactID, String companyName, String streetAddress, String state, int zipCode) {
		this.id = id;
		this.contactID = contactID;
		
		this.companyName = companyName;
		this.streetAddress = streetAddress;
		this.state = state;
		this.zipCode = zipCode;
	}
	
	public int getId() {
		return (id);
	}
	public int getContactID() {
		return(contactID);
	}
	
	public String getCompanyName() {
		return (companyName);
	}
	public String getStreetAddress() {
		return (streetAddress);
	}
	public String getState() {
		return (state);
	}
	public int getZipCode() {
		return (zipCode);
	}

}
