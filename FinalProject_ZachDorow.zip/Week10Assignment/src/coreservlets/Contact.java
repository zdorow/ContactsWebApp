package coreservlets;

import java.io.Serializable;

/**
 * Simple representation of an employee. Used to seed database initially.
 * Immutable.
 * <p>
 * From <a href="http://courses.coreservlets.com/Course-Materials/">the
 * coreservlets.com tutorials on servlets, JSP, Struts, JSF, Ajax, GWT, Spring,
 * Hibernate/JPA, and Java programming</a>.
 */

public class Contact implements Serializable {

	private static final long serialVersionUID = 3773608782961342552L;

	private String firstName, middleName, lastName;
	private int id;

	public Contact() {		
	}
	
	public Contact(int id, String firstName, String middleName, String lastName) {
		this.id = id;
		
		this.firstName = firstName;
		this.middleName = middleName;
		this.lastName = lastName;

	}

	public int getId() {
		return (id);
	}

	public String getFirstName() {
		return (firstName);
	}

	public String getMiddleName() {
		return (middleName);
	}

	public String getLastName() {
		return (lastName);
	}

}
