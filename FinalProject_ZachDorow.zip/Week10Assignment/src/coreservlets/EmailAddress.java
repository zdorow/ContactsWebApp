package coreservlets;

import java.io.Serializable;

public class EmailAddress implements Serializable {

	private static final long serialVersionUID = 3773608782961342555L;
	
	private String emailAddress;
	private int id, contactID;

	public EmailAddress() {

	}

	public EmailAddress(int id, int contactID, String emailAddress) {
		this.id = id;
		this.contactID = contactID;
		
		this.emailAddress = emailAddress;		
	}

	public int getId() {
		return (id);
	}
	public int getContactID() {
		return(contactID);
	}
	
	public String getEmailAddress() {
		return (emailAddress);
	}
}
