package coreservlets;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class EditInfo {
	
	protected final static String contactTable = "contact";
	protected final static String addressTable = "address";
	protected final static String phoneTable = "phone";
	protected final static String emailAddressTable = "emailAddress";
	protected final static String employerTable = "employer";
	
//Editing Contact information in the database
	public static void EditContact(int id, String firstName, String middleName, String lastName) throws Exception {

		Connection contactConnection = Get.getConnection();
		String contactTemplate = "UPDATE " + contactTable + " SET " + " firstName = ?," + " middleName = ?," + " lastName = ?" + " WHERE id = ?";
		PreparedStatement contactInserter = contactConnection.prepareStatement(contactTemplate);
			
			contactInserter.setString(1, firstName);
			contactInserter.setString(2, middleName);
			contactInserter.setString(3, lastName);
			contactInserter.setInt(4, id);
			contactInserter.executeUpdate();
			System.out.printf("Updated %s %s.%n", firstName, lastName);
		contactInserter.close();
		contactConnection.close();
	}

	//Editing Address information in the database
	public static void EditAddress(int id, String streetAddress, String state, int zipCode) throws Exception {
		Connection addressConnection = Get.getConnection();
		String addressTemplate = "UPDATE " + addressTable + " SET " + " streetAddress = ?," + " state = ?," + " zipCode = ?" + " WHERE id = ?";
		PreparedStatement addressInserter = addressConnection.prepareStatement(addressTemplate);
			
			addressInserter.setString(1, streetAddress);
			addressInserter.setString(2, state);
			addressInserter.setInt(3, zipCode);
			addressInserter.setInt(4, id);
			
			addressInserter.executeUpdate();
			System.out.printf("Updated %s %s %s %s.%n", id, streetAddress, state, zipCode);
		addressInserter.close();
		addressConnection.close();
	}

	//Editing Phone Number information in the database
	public static void EditPhoneNumber(int id, int areaCode, int exchange, int extension) throws Exception {
		Connection phoneNumberConnection = Get.getConnection();
		String phoneNumberTemplate = "UPDATE " + phoneTable + " SET " + " areaCode = ?," + " exchange = ?," + " extension = ?" + " WHERE id = ?";
		PreparedStatement phoneNumberInserter = phoneNumberConnection.prepareStatement(phoneNumberTemplate);
			
			phoneNumberInserter.setInt(1, areaCode);
			phoneNumberInserter.setInt(2, exchange);
			phoneNumberInserter.setInt(3, extension);
			phoneNumberInserter.setInt(4, id);
			
			phoneNumberInserter.executeUpdate();
			System.out.printf("Updated %s-%s-%s.%n", areaCode, exchange, extension);
		phoneNumberInserter.close();
		phoneNumberConnection.close();
	}

	//Editing Email Address information in the database
	public static void EditEmailAddresses(int id, String emailAddress) throws Exception {
		Connection emailAddressConnection = Get.getConnection();
		String emailAddressTemplate = "UPDATE " + emailAddressTable + " SET " + " emailAddress = ?" + " WHERE id = ?";
		PreparedStatement emailAddressInserter = emailAddressConnection.prepareStatement(emailAddressTemplate);
			
			emailAddressInserter.setString(1, emailAddress);
			emailAddressInserter.setInt(2, id);
			
			emailAddressInserter.executeUpdate();
			System.out.printf("Updated %s.%n", emailAddress);
			
		emailAddressInserter.close();
		emailAddressConnection.close();
	}

	//Editing Employer information in the database
	public static void EditEmployer(int id, String companyName, String streetAddress, String state, int zipCode) throws Exception {
		Connection employerConnection = Get.getConnection();
		String employerTemplate = "UPDATE " + employerTable + " SET " + " companyName = ?," + " streetAddress = ?," + " state = ?," + "zipCode = ?" + " WHERE id = ?";
		PreparedStatement employerInserter = employerConnection.prepareStatement(employerTemplate);
						
			employerInserter.setString(1, companyName);
			employerInserter.setString(2, streetAddress);
			employerInserter.setString(3, state);
			employerInserter.setInt(4, zipCode);
			employerInserter.setInt(5, id);

			employerInserter.executeUpdate();
			System.out.printf("Updated %s %s %s %s.%n", companyName, streetAddress, state, zipCode);
		employerInserter.close();
		employerConnection.close();
	}
}
