package coreservlets;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class Add {
	protected final static String contactTable = "contact";
	protected final static String addressTable = "address";
	protected final static String phoneTable = "phone";
	protected final static String emailAddressTable = "emailAddress";
	protected final static String employerTable = "employer";
	
	
	String format = "VARCHAR(30)";
	public Add() {
	}

	//Adds a Contact from servlet input
	
	public static int AddContact(String firstName, String middleName, String lastName) throws Exception {
		
		//Generation of Contact ID
		int id = Get.GetContactTotal() + 150;
		
		Connection contactConnection = Get.getConnection();
		String contactTemplate = String.format("INSERT INTO %s VALUES(?, ?, ?, ?)", contactTable);
		PreparedStatement contactInserter = contactConnection.prepareStatement(contactTemplate);
			contactInserter.setInt(1, id);
			
			contactInserter.setString(2, firstName);
			contactInserter.setString(3, middleName);
			contactInserter.setString(4, lastName);
			contactInserter.executeUpdate();
			System.out.printf("Inserted %s %s.%n", firstName, lastName);
		contactInserter.close();
		contactConnection.close();
		
		return id;
	}
	
	//Adds a Address from servlet input

	public static void AddAddress(int contactID, String streetAddress, String state, int zipCode) throws Exception {
		
		//Generation of Address ID
		int id = Get.GetAddressTotal() + 1;
		
		Connection addressConnection = Get.getConnection();
		String addressTemplate = String.format("INSERT INTO %s VALUES(?, ?, ?, ?, ?)", addressTable);
		PreparedStatement addressInserter = addressConnection.prepareStatement(addressTemplate);
			addressInserter.setInt(1, id);
			addressInserter.setInt(2, contactID);
			
			addressInserter.setString(3, streetAddress);
			addressInserter.setString(4, state);
			addressInserter.setInt(5, zipCode);
			addressInserter.executeUpdate();
			System.out.printf("Inserted %s %s %s %s.%n", id, streetAddress, state, zipCode);
		addressInserter.close();
		addressConnection.close();
	
	}

	//Adds a Phone Number from servlet
	
	public static void AddPhoneNumber(int contactID, int areaCode, int exchange, int extension) throws Exception {
		
		//Generation of Phone Number ID
		int id = Get.GetPhoneNumberTotal() + 1;
		
		Connection phoneNumberConnection = Get.getConnection();
		String phoneNumberTemplate = String.format("INSERT INTO %s VALUES(?, ?, ?, ?, ?)", phoneTable);
		PreparedStatement phoneNumberInserter = phoneNumberConnection.prepareStatement(phoneNumberTemplate);
			phoneNumberInserter.setInt(1, id);
			phoneNumberInserter.setInt(2, contactID);
			
			phoneNumberInserter.setInt(3, areaCode);
			phoneNumberInserter.setInt(4, exchange);
			phoneNumberInserter.setInt(5, extension);
			
			phoneNumberInserter.executeUpdate();
			System.out.printf("Inserted %s %s-%s-%s.%n",  contactID, areaCode, exchange, extension);
		phoneNumberInserter.close();
		phoneNumberConnection.close();
	}

	//Adds an Email Address from servlet 
	
	public static void AddEmailAddresses(int contactID, String emailAddress) throws Exception {
		
		//Generation of Email Address ID
		int id = Get.GetEmailAddressesTotal() + 1;
		
		Connection emailAddressConnection = Get.getConnection();
		String emailAddressTemplate = String.format("INSERT INTO %s VALUES(?, ?, ?)", emailAddressTable);
		PreparedStatement emailAddressInserter = emailAddressConnection.prepareStatement(emailAddressTemplate);
			emailAddressInserter.setInt(1, id);
			emailAddressInserter.setInt(2, contactID);
			
			emailAddressInserter.setString(3, emailAddress);
			emailAddressInserter.executeUpdate();
			System.out.printf("Inserted %s.%n", emailAddress);
			
		emailAddressInserter.close();
		emailAddressConnection.close();
	}

	//Adds Employer from servlet
	
	public static void AddEmployer(int contactID, String companyName, String streetAddress, String state, int zipCode) throws Exception {
		
		//Generation of Employer ID 
		int id = Get.GetEmployersTotal() + 1;
		
		Connection employerConnection = Get.getConnection();
		String employerTemplate = String.format("INSERT INTO %s VALUES(?, ?, ?, ?, ?, ?)", employerTable);
		PreparedStatement employerInserter = employerConnection.prepareStatement(employerTemplate);
			employerInserter.setInt(1, id);
			employerInserter.setInt(2, contactID);
			
			employerInserter.setString(3, companyName);
			employerInserter.setString(4, streetAddress);
			employerInserter.setString(5, state);
			employerInserter.setInt(6, zipCode);
			employerInserter.executeUpdate();
			System.out.printf("Inserted %s %s %s %s.%n", companyName, streetAddress, state, zipCode);
		employerInserter.close();
		employerConnection.close();
	}
}
