package coreservlets;

import java.sql.*;
import java.util.*;

/**
 * Creates "myDatabase" DB ADDED tables for each bean we wanted to use for project edited as needed Show Tables function not used
 * <p>
 * From <a href="http://courses.coreservlets.com/Course-Materials/">the
 * coreservlets.com tutorials on servlets, JSP, Struts, JSF, Ajax, GWT, Spring,
 * Hibernate/JPA, and Java programming</a>.
 */

public class EmbeddedDbCreator {
	// Driver class not needed in JDBC 4.0 (Java SE 6)  ADDED tables for each bean we wanted to use for project
	// private String driver = "org.apache.derby.jdbc.EmbeddedDriver";
	private String protocol = "jdbc:derby:";
	private String username = "someuser";
	private String password = "somepassword";
	private String dbName = "myDatabase";
	private String contactTable = "contact";
	private String addressTable = "address";
	private String phoneTable = "phone";
	private String employerTable = "employer";
	private String emailAddressTable = "emailAddress";
			
	private Properties userInfo;

	public EmbeddedDbCreator() {
		userInfo = new Properties();
		userInfo.put("user", username);
		userInfo.put("password", password);
	}

	public void createDatabase() {
		
		Contact[] Contacts = { 
				new Contact(111, "Larry", "Gary", "Ellison"),
				new Contact(112, "Charles", "InCharge", "Phillips"),
				new Contact(113, "Safra", "Catz",  "Kiteen"),
				new Contact(114, "Keith", "Block",  "Buffer"),
				new Contact(115, "Thomas", "Kurian",  "Joehansen"),
				new Contact(116, "Joe", "Hacker",  "Hackerson"), 
				new Contact(117, "Jane", "Hacker",  "Hackerson"),
				new Contact(118, "David", "Developer",  "Devson"),
				new Contact(119, "Danielle", "Developer",  "Devson"),
				new Contact(120, "Cody", "Coder",  "Codeson"), 
				new Contact(121, "Cathy", "Coder",  "Codeson"),
				new Contact(122, "Gary", "Grunt",  "Ewokt"), 
				new Contact(123, "Gabby", "Grunt",  "Ewokt")};
		
		Address[] Addresses = { 
				new Address(1, 111, "123 Main Street", "WI", 12345),
				new Address(14, 111, "444 Wigwam Street", "WA", 54321),
				new Address(2, 112, "124 Main Street", "WI", 12345),
				new Address(3, 113, "125 Main Street", "WI", 12345),
				new Address(4, 114, "126 Main Street", "WI", 12345),
				new Address(5, 115, "127 Main Street", "WI", 12345),
				new Address(6, 116, "128 Main Street", "WI", 12345), 
				new Address(7, 117, "129 Main Street", "WI", 12345),
				new Address(8, 118, "130 Main Street", "WI", 12345),
				new Address(9, 119, "131 Main Street", "WI", 12345),
				new Address(10, 120, "132 Main Street", "WI", 12345), 
				new Address(11, 121, "133 Main Street", "WI", 12345),
				new Address(12, 122, "134 Main Street", "WI", 12345), 
				new Address(13, 123, "135 Main Street", "WI", 12345)};
		
		PhoneNumber[] PhoneNumbers = {
				new PhoneNumber(1,111,876,543,2100),
				new PhoneNumber(14,111,123,456,7890),
				new PhoneNumber(2,112,123,456,7891),
				new PhoneNumber(3,113,123,456,7892),
				new PhoneNumber(4,114,123,456,7893),
				new PhoneNumber(5,115,123,456,7894),
				new PhoneNumber(6,116,123,456,7895), 
				new PhoneNumber(7,117,123,456,7896),
				new PhoneNumber(8,118,123,456,7897),
				new PhoneNumber(9,119,123,456,7898),
				new PhoneNumber(10,120,123,456,7899), 
				new PhoneNumber(11,121,123,456,7800),
				new PhoneNumber(12,122,123,456,7810), 
				new PhoneNumber(13,123,123,456,7820)};
		
		EmailAddress[] EmailAddresses = { 
				new EmailAddress(1, 111, "Larry@gmail.com"),
				new EmailAddress(14, 111, "larryTheWild@hotmail.com"),
				new EmailAddress(2, 112, "Charles@gmail.com"),
				new EmailAddress(3, 113, "Safra@gmail.com"),
				new EmailAddress(4, 114, "Keith@gmail.com"),
				new EmailAddress(5, 115, "Thomas@gmail.com"),
				new EmailAddress(6, 116, "Joe@gmail.com"), 
				new EmailAddress(7, 117, "Jane@gmail.com"),
				new EmailAddress(8, 118, "David@gmail.com"),
				new EmailAddress(9, 119, "Danielle@gmail.com"),
				new EmailAddress(10, 120, "Cody@gmail.com"), 
				new EmailAddress(11, 121, "Cathy@gmail.com"),
				new EmailAddress(12, 122, "Gary@gmail.com"), 
				new EmailAddress(13, 123, "Gabby@gmail.com")};
		
		Employer[] Employers = { 
				new Employer(1, 111, "Quiznos", "224 Second Street", "WI", 12345),
				new Employer(14, 111, "Quiznos Extreme", "224 Fifth Street", "WI", 12345),
				new Employer(2, 112, "Blockbuster", "222 Second Street", "WI", 22345),
				new Employer(3, 113, "Wells Fargo", "227 Second Street", "WI", 22345),
				new Employer(4, 114, "Festival", "123 Main Street", "WI", 14345),
				new Employer(5, 115, "Quiznos", "221 Second Street", "WI", 16345),
				new Employer(6, 116, "Cray", "223 Second Street", "WI", 18345),
				new Employer(7, 117, "Burger King", "223 Second Street", "WI", 19345),
				new Employer(8, 118, "Menards", "223 Second Street", "WI", 19345),
				new Employer(9, 119, "Kwik Trip", "125 Main Street", "WI", 19345),
				new Employer(10, 120, "Entropy", "223 Second Street", "WI", 19345),
				new Employer(11, 121, "Salesforce", "423 Fourth Street", "WI", 19345),
				new Employer(12, 122, "Papa Johns", "323 Third Street", "WI", 12045),
				new Employer(13, 123, "The Livery", "223 Second Street", "WI", 12045)};
		
		try {
			String dbUrl = protocol + dbName + ";create=true";
			String format = "VARCHAR(30)";
			
//Contact Table creation			
			Connection contactConnection = DriverManager.getConnection(dbUrl, userInfo);			
			Statement contactStatement = contactConnection.createStatement();
			
			String contactTableDescription = String.format("CREATE TABLE %s" + "(id INT, firstname %s, middlename %s, lastname %s)", 
															contactTable, format, format, format);
			contactStatement.execute(contactTableDescription);
			String contactTemplate = String.format("INSERT INTO %s VALUES(?, ?, ?, ?)", contactTable);
			PreparedStatement contactInserter = contactConnection.prepareStatement(contactTemplate);
			
			for (Contact c : Contacts) {
				contactInserter.setInt(1, c.getId());
				
				contactInserter.setString(2, c.getFirstName());
				contactInserter.setString(3, c.getMiddleName());
				contactInserter.setString(4, c.getLastName());
				contactInserter.executeUpdate();
				System.out.printf("Inserted %s %s.%n", c.getFirstName(), c.getLastName());
			}
			contactInserter.close();
			contactConnection.close();
			
//Address Table creation
			Connection addressConnection = DriverManager.getConnection(dbUrl, userInfo);
			Statement addressStatement = addressConnection.createStatement();
			
			String addressTableDescription = String.format(
					"CREATE TABLE %s" + "(id INT, contactID INT, streetAddress %s, state %s, zipCode INT)", addressTable, 
												format, format);
			addressStatement.execute(addressTableDescription);
			String addressTemplate = String.format("INSERT INTO %s VALUES(?, ?, ?, ?, ?)", addressTable);
			PreparedStatement addressInserter = addressConnection.prepareStatement(addressTemplate);
			for (Address a : Addresses) {
				addressInserter.setInt(1, a.getId());
				addressInserter.setInt(2, a.getContactID());
				
				addressInserter.setString(3, a.getStreetAddress());
				addressInserter.setString(4, a.getState());
				addressInserter.setInt(5, a.getZipCode());
				addressInserter.executeUpdate();
				System.out.printf("Inserted %s %s %s %s.%n", a.getContactID(), a.getStreetAddress(), a.getZipCode(), a.getState());
			}
			addressInserter.close();
			addressConnection.close();
			
//PhoneNumber Table Creation
			Connection phoneNumberConnection = DriverManager.getConnection(dbUrl, userInfo);
			Statement phoneNumberStatement = phoneNumberConnection.createStatement();
			
			String phoneNumberTableDescription = String.format("CREATE TABLE %s" + "(id INT, contactID INT, areaCode INT, exchange INT, extension INT)", phoneTable);
			phoneNumberStatement.execute(phoneNumberTableDescription);
			String phoneNumberTemplate = String.format("INSERT INTO %s VALUES(?, ?, ?, ?, ?)", phoneTable);
			PreparedStatement phoneNumberInserter = phoneNumberConnection.prepareStatement(phoneNumberTemplate);
			for (PhoneNumber p : PhoneNumbers) {
				phoneNumberInserter.setInt(1, p.getId());
				phoneNumberInserter.setInt(2, p.getContactID());
				
				phoneNumberInserter.setInt(3, p.getAreaCode());
				phoneNumberInserter.setInt(4, p.getExchange());
				phoneNumberInserter.setInt(5, p.getExtension());
				
				phoneNumberInserter.executeUpdate();
				System.out.printf("Inserted %s %s-%s-%s.%n",  p.getContactID(), p.getAreaCode(), p.getExchange(), p.getExtension());
			}
			phoneNumberInserter.close();
			phoneNumberConnection.close();
			
//EmailAddress Table Creation
			Connection emailAddressConnection = DriverManager.getConnection(dbUrl, userInfo);
			Statement emailAddressStatement = emailAddressConnection.createStatement();
			
			String emailAddressTableDescription = String.format("CREATE TABLE %s" + "(id INT, contactID INT, emailAddress %s)", emailAddressTable, format);
			emailAddressStatement.execute(emailAddressTableDescription);
			String emailAddressTemplate = String.format("INSERT INTO %s VALUES(?, ?, ?)", emailAddressTable);
			PreparedStatement emailAddressInserter = emailAddressConnection.prepareStatement(emailAddressTemplate);
			for (EmailAddress e : EmailAddresses) {
				emailAddressInserter.setInt(1, e.getId());
				emailAddressInserter.setInt(2, e.getContactID());
				
				emailAddressInserter.setString(3, e.getEmailAddress());
				emailAddressInserter.executeUpdate();
				System.out.printf("Inserted %s.%n", e.getEmailAddress());
			}
			emailAddressInserter.close();
			emailAddressConnection.close();
			
//Employer Table Creation	
			Connection employerConnection = DriverManager.getConnection(dbUrl, userInfo);
			Statement employerStatement = employerConnection.createStatement();
			
			String employerTableDescription = String.format("CREATE TABLE %s" + "(id INT, contactID INT, companyName %s, streetAddress %s, state %s, zipCode INT)", employerTable, format, format, format);
			employerStatement.execute(employerTableDescription);
			String employerTemplate = String.format("INSERT INTO %s VALUES(?, ?, ?, ?, ?, ?)", employerTable);
			PreparedStatement employerInserter = employerConnection.prepareStatement(employerTemplate);
			for (Employer em : Employers) {
				employerInserter.setInt(1, em.getId());
				employerInserter.setInt(2, em.getContactID());
				
				employerInserter.setString(3, em.getCompanyName());
				employerInserter.setString(4, em.getStreetAddress());
				employerInserter.setString(5, em.getState());
				employerInserter.setInt(6, em.getZipCode());
				employerInserter.executeUpdate();
				System.out.printf("Inserted %s %s %s %s.%n", em.getCompanyName(), em.getStreetAddress(), em.getState(), em.getZipCode());
			}
			employerInserter.close();
			employerConnection.close();
			
		} catch (SQLException sqle) {
			// If table already exists, then skip everything else
			System.err.println("Error Making Table: " + sqle);
		}
	}

	public void showTables() {
		try {
			String dbUrl = protocol + dbName;
			Connection connection;
			connection = DriverManager.getConnection(dbUrl, userInfo);
			Statement statement = connection.createStatement();
			String allContactsQuery = String.format("SELECT * FROM %s", contactTable);
			ResultSet contactsResultSet = statement.executeQuery(allContactsQuery);
			while (contactsResultSet.next()) {
				int id = contactsResultSet.getInt("id");
				String firstName = contactsResultSet.getString("firstname");
				String middleName = contactsResultSet.getString("middleName");
				String lastName = contactsResultSet.getString("lastname");
				System.out.printf("%s %s (%s, id=%s) %n", id, firstName, middleName, lastName);
			}
			
			String allAddressesQuery = String.format("SELECT * FROM %s", addressTable);
			ResultSet addressesResultSet = statement.executeQuery(allAddressesQuery);
			
			while (addressesResultSet.next()) {
				int id = addressesResultSet.getInt("id");
				String streetAddress = addressesResultSet.getString("streetAddress");
				String state = addressesResultSet.getString("state");
				int zipCode = addressesResultSet.getInt("zipCode");
				System.out.printf("%s %s %s %s %n", id, streetAddress, state, zipCode);				
			}
			
			connection.close();
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		}
	}

//Dropping tables for clean runs on server reboot		
	public void removeTable() {
		String dbUrl = protocol + dbName + ";create=true";

		try {
			Connection contactConnection = DriverManager.getConnection(dbUrl, userInfo);
			Statement contactStatement = contactConnection.createStatement();
			String contactTableDropStatement = String.format("DROP TABLE %s", contactTable);
			contactStatement.execute(contactTableDropStatement);
			
			Connection addressConnection = DriverManager.getConnection(dbUrl, userInfo);
			Statement addressStatement = addressConnection.createStatement();
			String addressTableDropStatement = String.format("DROP TABLE %s", addressTable);
			addressStatement.execute(addressTableDropStatement);
			
			Connection phoneNumberConnection = DriverManager.getConnection(dbUrl, userInfo);
			Statement phoneNumberStatement = phoneNumberConnection.createStatement();
			String phoneNumberDropStatement = String.format("DROP TABLE %s", phoneTable);
			phoneNumberStatement.execute(phoneNumberDropStatement);
			
			Connection emailAddressConnection = DriverManager.getConnection(dbUrl, userInfo);
			Statement emailAddressStatement = emailAddressConnection.createStatement();
			String emailAddressDropStatement = String.format("DROP TABLE %s", emailAddressTable);
			emailAddressStatement.execute(emailAddressDropStatement);
			
			Connection employerConnection = DriverManager.getConnection(dbUrl, userInfo);
			Statement employerStatement = employerConnection.createStatement();
			String employerDropStatement = String.format("DROP TABLE %s", employerTable);
			employerStatement.execute(employerDropStatement);
			
		} catch (SQLException e) {
			System.err.println("Error Dropping Table: " + e);
			e.printStackTrace();
		}
	
}

	public static void main(String[] args) {
		EmbeddedDbCreator tester = new EmbeddedDbCreator();
		tester.createDatabase();
		tester.showTables();
	}
}
