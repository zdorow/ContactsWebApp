package coreservlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import coreservlets.Address;
import coreservlets.Contact;
import coreservlets.EditInfo;
import coreservlets.EmailAddress;
import coreservlets.Employer;
import coreservlets.Get;
import coreservlets.PhoneNumber;
import coreservlets.Validation;

/**
 * Servlet implementation class AddController for editing the elements of a contact in the database
 */
@WebServlet("/EditController")
public class EditController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public EditController() {
        super();
    }

    // POST only servlet 

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String contactID = request.getParameter("id");
		String entryID = request.getParameter("entryID");
		
		Boolean EditContact = Boolean.parseBoolean(request.getParameter("EditContact"));		
		Boolean EditAddress = Boolean.parseBoolean(request.getParameter("EditAddress"));
		Boolean EditNumber = Boolean.parseBoolean(request.getParameter("EditNumber"));
		Boolean EditEmailAddress = Boolean.parseBoolean(request.getParameter("EditEmailAddress"));		
		Boolean EditEmployer = Boolean.parseBoolean(request.getParameter("EditEmployer"));
		Boolean Complete = Boolean.parseBoolean(request.getParameter("Complete"));
		
//Edit Logic if any of these is send as true it will pass on to direction login
	if (EditContact || EditAddress || EditNumber || EditEmailAddress || EditEmployer || Complete){
		
		//If adding the contact is complete then we validate and move to success page 
			if (EditContact && Complete){
					String firstName = request.getParameter("firstName");
					String middleName = request.getParameter("middleName");
					String lastName = request.getParameter("lastName"); 
					
					if(Validation.isContactValid(firstName, middleName, lastName))
							{
						int cID = Integer.parseInt(contactID);
						System.out.println(cID + firstName + middleName + lastName);
					try {
						EditInfo.EditContact(cID, firstName, middleName, lastName);
					} catch (Exception e) {
						System.out.println("Error Edting Contact");
						e.printStackTrace();
					}
					request.setAttribute("id", contactID);
					RequestDispatcher dispatcher = request.getRequestDispatcher("/EditSuccess.jsp");
					dispatcher.forward(request, response);
					}
					else {					
						request.setAttribute("Invalid", "Invalid Email Address");
						
						request.setAttribute("id", contactID);
						request.setAttribute("firstName", firstName);
						request.setAttribute("middleName", middleName);
						request.setAttribute("lastName", lastName);
						
				    	RequestDispatcher dispatcher = request.getRequestDispatcher("/EditContact.jsp");
				        dispatcher.forward(request, response);

				        }
			}
			
			//Initial Contact edit page
			
			else if (EditContact){
				try {
					
					//passing entries into fields on first run
					
						List<Contact> ContactDetail = Get.GetContactDetail(contactID);
						for (Contact c : ContactDetail) {
						request.setAttribute("id", c.getId());
						request.setAttribute("firstName", c.getFirstName());
						request.setAttribute("middleName", c.getMiddleName());
						request.setAttribute("lastName", c.getLastName());
						}
			} catch (Exception e) {
				System.out.println("Error Gathering Contact Details");
				e.printStackTrace();
				
			}						
						request.setAttribute("id", contactID);
						RequestDispatcher dispatcher = request.getRequestDispatcher("/EditContact.jsp");
					    dispatcher.forward(request, response);
					}
			
		// Validation of address entry and passed to success if valid
			
			else if (EditAddress && Complete){

				String addressID = request.getParameter("addressID");
				String streetAddress = request.getParameter("streetAddress");
				String state = request.getParameter("state");
				String zipCode = request.getParameter("zipCode");
				
				if (Validation.isAddressValid(streetAddress, state, zipCode))
				{				
					int aID = Integer.parseInt(addressID);
					int zip = Integer.parseInt(zipCode);
				try {
					EditInfo.EditAddress(aID, streetAddress, state, zip);
				} catch (Exception e) {
					System.out.println("Error Editing Address Details");
					e.printStackTrace();
				}
				request.setAttribute("id", contactID);
				RequestDispatcher dispatcher = request.getRequestDispatcher("/EditSuccess.jsp");
				dispatcher.forward(request, response);
				}
				else {
					
		//Reseting of request attributes for validation failure
					
					request.setAttribute("Invalid", "Invalid Entry");
					request.setAttribute("id", contactID);
					request.setAttribute("addressID", addressID);
					request.setAttribute("streetAddress", streetAddress);
					request.setAttribute("state", state);
					request.setAttribute("zipCode", zipCode);
			    	RequestDispatcher dispatcher = request.getRequestDispatcher("/EditAddress.jsp");
			        dispatcher.forward(request, response);
				}
			}
			
		//Initial Address Entry page
			
			else if (EditAddress){
				try {
					
					//passing entries into fields on first run
					
					List<Address> AddressDetail = Get.GetAddress(entryID);
					for (Address c : AddressDetail) {
					request.setAttribute("addressID", c.getId());
					request.setAttribute("id", c.getContactID());
					request.setAttribute("streetAddress", c.getStreetAddress());
					request.setAttribute("zipCode", c.getZipCode());
					request.setAttribute("state", c.getState());
					}
				} catch (Exception e) {
					System.out.println("Error Getting Address Details");
					e.printStackTrace();
				}
				request.setAttribute("id", contactID);
				RequestDispatcher dispatcher = request.getRequestDispatcher("/EditAddress.jsp");
			    dispatcher.forward(request, response);
			}
			
			// Validation of Number entry and passed to success if valid
			
			else if (EditNumber && Complete){
				
				String phoneNumberID = request.getParameter("phoneNumberID");

				String areaCode = request.getParameter("areaCode");
				String exchange = request.getParameter("exchange");
				String extension = request.getParameter("extension");
				if (Validation.isPhoneNumberValid(areaCode, exchange, extension))
				{
				int pID = Integer.parseInt(phoneNumberID);
				int aC = Integer.parseInt(areaCode);
				int ex = Integer.parseInt(exchange);
				int ext = Integer.parseInt(extension);
				try {
					EditInfo.EditPhoneNumber(pID, aC, ex, ext);
				} catch (Exception e) {
					System.out.println("Error Editing Phone Number Details");
					e.printStackTrace();
				}
				request.setAttribute("id", contactID);
				RequestDispatcher dispatcher = request.getRequestDispatcher("/EditSuccess.jsp");
				dispatcher.forward(request, response);
			}
				else {
					
	//Reseting of request attributes for validation failure 
					
					request.setAttribute("Invalid", "Invalid Phone Number");
					request.setAttribute("id", contactID);
					request.setAttribute("phoneNumberID", phoneNumberID);
					request.setAttribute("areaCode", areaCode);
					request.setAttribute("exchange", exchange);
					request.setAttribute("extension", extension);
					
			    	RequestDispatcher dispatcher = request.getRequestDispatcher("/EditPhoneNumber.jsp");
			        dispatcher.forward(request, response);
				}
			}
			
			else if (EditNumber){
				try {
					
					//passing entries into fields on first run
					
					List<PhoneNumber> phoneNumberDetail = Get.GetPhoneNumber(entryID);
					for (PhoneNumber c : phoneNumberDetail) {
					request.setAttribute("phoneNumberID", c.getId());
					request.setAttribute("id", c.getContactID());
					request.setAttribute("areaCode", c.getAreaCode());
					request.setAttribute("exchange", c.getExchange());
					request.setAttribute("extension", c.getExtension());
					}
				} catch (Exception e) {
					System.out.println("Error Getting Phone Number Details");
					e.printStackTrace();
				}
				request.setAttribute("id", contactID);
				RequestDispatcher dispatcher = request.getRequestDispatcher("/EditPhoneNumber.jsp");
			    dispatcher.forward(request, response);
				
			}
			
			else if (EditEmailAddress && Complete){
				String emailAddressID = request.getParameter("emailAddressID");				
				String emailAddress = request.getParameter("emailAddress");
				if (Validation.isEmailAddressValid(emailAddress))
				{
				int EaID = Integer.parseInt(emailAddressID);
				try {
					EditInfo.EditEmailAddresses(EaID, emailAddress);
				} catch (Exception e) {
					System.out.println("Error Editing Email Address Details");
					e.printStackTrace();
				}
				request.setAttribute("id", contactID);
				RequestDispatcher dispatcher = request.getRequestDispatcher("/EditSuccess.jsp");
				dispatcher.forward(request, response);
				}
				else {
					
					//Reseting of request attributes for validation failure 
					
					request.setAttribute("Invalid", "Invalid Email Address");
					request.setAttribute("id", contactID);
					request.setAttribute("emailAddress", emailAddress);
					request.setAttribute("emailAddressID", emailAddressID);
			    	RequestDispatcher dispatcher = request.getRequestDispatcher("/EditEmailAddress.jsp");
			        dispatcher.forward(request, response);

			        }
			}
			
			else if (EditEmailAddress){
				
				//Email Address Request
				
				try {
					List<EmailAddress> emailAddressDetail = Get.GetEmailAddress(entryID);
					for (EmailAddress c : emailAddressDetail) {
						request.setAttribute("emailAddressID", c.getId());
						request.setAttribute("id", c.getContactID());
						request.setAttribute("emailAddress", c.getEmailAddress());
						}
					
				} catch (Exception e) {
					System.out.println("Error Getting Email Address Details");
					e.printStackTrace();
				}
				request.setAttribute("id", contactID);
				
				RequestDispatcher dispatcher = request.getRequestDispatcher("/EditEmailAddress.jsp");
			    dispatcher.forward(request, response);
			}
			
			else if (EditEmployer && Complete){
				String employerID = request.getParameter("employerID");
				
				String employer = request.getParameter("employer");
				String employerStreetAddress = request.getParameter("employerStreetAddress");
				String employerState = request.getParameter("employerState");
				String employerZipCode = request.getParameter("employerZipCode");
				
				if (Validation.isEmployerValid(employer, employerStreetAddress, employerState, employerZipCode))
				{
				int eID = Integer.parseInt(employerID);
				int eZip = Integer.parseInt(employerZipCode);
				try {
					EditInfo.EditEmployer(eID, employer, employerStreetAddress, employerState, eZip);
				} catch (Exception e) {
					System.out.println("Error Editing Employer Details");
					e.printStackTrace();
				}
				request.setAttribute("id", contactID);
				RequestDispatcher dispatcher = request.getRequestDispatcher("/EditSuccess.jsp");
				dispatcher.forward(request, response);
				}
				else {
					
		//Reseting of request attributes for validation failure 
					
					request.setAttribute("Invalid", "Invalid Employer");
					request.setAttribute("employerID", employerID);
					request.setAttribute("employer", employer);
					request.setAttribute("employerStreetAddress", employerStreetAddress);
					request.setAttribute("employerState", employerState);
					request.setAttribute("employerZipCode", employerZipCode);
					request.setAttribute("id", contactID);
					
			    	RequestDispatcher dispatcher = request.getRequestDispatcher("/EditEmployer.jsp");
			        dispatcher.forward(request, response);

			        }
			}
			
			else if (EditEmployer){
				try {
					
		//Initial setting of request attributes 
					
					List<Employer> employerDetail = Get.GetEmployer(entryID);
					for (Employer c : employerDetail) {
						request.setAttribute("employerID", c.getId());
						request.setAttribute("id", c.getContactID());
						request.setAttribute("employer", c.getCompanyName());
						request.setAttribute("employerStreetAddress", c.getStreetAddress());
						request.setAttribute("employerState", c.getState());
						request.setAttribute("employerZipCode", c.getZipCode());
						
						}
				} catch (Exception e) {
					System.out.println("Error Getting Employer Details");
					e.printStackTrace();
				}
				request.setAttribute("id", contactID);
				RequestDispatcher dispatcher = request.getRequestDispatcher("/EditEmployer.jsp");
			    dispatcher.forward(request, response); 
			}						

		}
	else
	{
		RequestDispatcher dispatcher = request.getRequestDispatcher("/EmployeeList.jsp");
		dispatcher.forward(request, response);
	}
	}

}
