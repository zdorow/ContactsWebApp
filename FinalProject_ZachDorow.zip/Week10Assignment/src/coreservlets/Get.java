package coreservlets;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class Get {
	private final static String driver = "org.apache.derby.jdbc.EmbeddedDriver";
	protected final static String dbName = "myDatabase";
	protected final static String url = "jdbc:derby:" + dbName;
	protected final static String contactTable = "contact";
	protected final static String addressTable = "address";
	protected final static String phoneTable = "phone";
	protected final static String emailAddressTable = "emailAddress";
	protected final static String employerTable = "employer";
	protected final static String username = "someuser";
	protected final static String password = "somepassword";
	
	public Get() {

	}
	
	//Returns Total of Contacts	
	
		public static int GetContactTotal() throws Exception {
			int ContactTotal = GetContactList("0").size();
			
			return ContactTotal;
		}	
		
		//Returns Total of Addresses	
		
		public static int GetAddressTotal() throws Exception {
			Connection addressConnection = Get.getConnection();
			Statement adressStatement = addressConnection.createStatement();
			String addressQuery = "SELECT COUNT(*) FROM " + addressTable ;
			ResultSet addressResultSet = adressStatement.executeQuery(addressQuery);
			addressResultSet.next();
			int AddressTotal = addressResultSet.getInt(1);
			
			return AddressTotal;
		}
		
		//Returns Total of phoneNumber
		
		public static int GetPhoneNumberTotal() throws Exception {
			Connection phoneNumberConnection = Get.getConnection();
			Statement phoneNumberStatement = phoneNumberConnection.createStatement();
			String phoneNumberQuery = "SELECT COUNT(*) FROM " + phoneTable ;
			ResultSet phoneNumberResultSet = phoneNumberStatement.executeQuery(phoneNumberQuery);
			phoneNumberResultSet.next();
			int phoneNumberTotal = phoneNumberResultSet.getInt(1);
			
			return phoneNumberTotal;
		}
		
		//Returns Total of EmailAddress	
		
		public static int GetEmailAddressesTotal() throws Exception {
			Connection emailAddressConnection = Get.getConnection();
			Statement EmailAddressStatement = emailAddressConnection.createStatement();
			String emailAddressQuery = "SELECT COUNT(*) FROM " + emailAddressTable ;
			ResultSet emailAddressResultSet = EmailAddressStatement.executeQuery(emailAddressQuery);
			emailAddressResultSet.next();
			int emailAddressTotal = emailAddressResultSet.getInt(1);
			
			return emailAddressTotal;
		}
		
		//Returns Total of Employers
		
		public static int GetEmployersTotal() throws Exception {
			Connection employersConnection = Get.getConnection();
			Statement employersStatement = employersConnection.createStatement();
			String employersQuery = "SELECT COUNT(*) FROM " + employerTable ;
			ResultSet employersResultSet = employersStatement.executeQuery(employersQuery);
			employersResultSet.next();
			int employersTotal = employersResultSet.getInt(1);
			
			return employersTotal;
		}
		
//Returns List of Contacts	
		
	public static List<Contact> GetContactList(String id) throws Exception {
		Connection connection = getConnection();
		String query = "SELECT * FROM " + contactTable;
		Statement statement = connection.createStatement();
		ResultSet resultSet = statement.executeQuery(query);
		List<Contact> ContactList = new ArrayList<Contact>();
		while (resultSet.next()) {
		ContactList.add(mapContact(connection, resultSet));
		}
		return ContactList;
	}

//Detail of Contacts	
	
	public static List<Contact> GetContactDetail(String id) throws Exception {
		Connection contactConnection = Get.getConnection();				
		Statement contactStatement = contactConnection.createStatement();				
		String contactQuery = "SELECT * FROM " + contactTable + " WHERE id = " + id;
		ResultSet contactResultSet = contactStatement.executeQuery(contactQuery);				
		List<Contact> ContactDetail = new ArrayList<Contact>();
		while (contactResultSet.next()) {
			ContactDetail.add(mapContact(contactConnection, contactResultSet));
		}
		return ContactDetail;
	}
	
//Detail of Address by Contact ID
	
	public static List<Address> GetAddressDetail(String id) throws Exception {
		Connection addressConnection = Get.getConnection();
		Statement adressStatement = addressConnection.createStatement();
		String addressQuery = "SELECT * FROM " + addressTable + " WHERE contactID = " + id;
		ResultSet addressResultSet = adressStatement.executeQuery(addressQuery);				
		List<Address> AddressDetail = new ArrayList<Address>();
		while (addressResultSet.next()) {
			AddressDetail.add(mapAddress(addressConnection, addressResultSet));
		}
		return AddressDetail;
	}
	
//Getting a specific address by id of address
	
	public static List<Address> GetAddress(String id) throws Exception {
		Connection addressConnection = Get.getConnection();
		Statement adressStatement = addressConnection.createStatement();
		String addressQuery = "SELECT * FROM " + addressTable + " WHERE id = " + id;
		ResultSet addressResultSet = adressStatement.executeQuery(addressQuery);				
		List<Address> Address = new ArrayList<Address>();
		while (addressResultSet.next()) {
			Address.add(mapAddress(addressConnection, addressResultSet));
		}
		return Address;
	}
	
//Detail of Phone Number by Contact ID	
	
	public static List<PhoneNumber> GetPhoneNumberDetail(String id) throws Exception {
		Connection phoneNumberConnection = getConnection();
		Statement phoneNumberStatement = phoneNumberConnection.createStatement();
		String phoneNumberQuery = "SELECT * FROM " + phoneTable + " WHERE contactID = " + id;
		ResultSet phoneNumbersResultSet = phoneNumberStatement.executeQuery(phoneNumberQuery);				
		List<PhoneNumber> phoneNumberDetail = new ArrayList<PhoneNumber>();
		while (phoneNumbersResultSet.next()) {
			phoneNumberDetail.add(mapPhoneNumber(phoneNumberConnection, phoneNumbersResultSet));
		}
		return phoneNumberDetail;
	}
	
//Detail of Phone Number by ID of phone number
	
	public static List<PhoneNumber> GetPhoneNumber(String id) throws Exception {
		Connection phoneNumberConnection = getConnection();
		Statement phoneNumberStatement = phoneNumberConnection.createStatement();
		String phoneNumberQuery = "SELECT * FROM " + phoneTable + " WHERE id = " + id;
		ResultSet phoneNumbersResultSet = phoneNumberStatement.executeQuery(phoneNumberQuery);				
		List<PhoneNumber> phoneNumber = new ArrayList<PhoneNumber>();
		while (phoneNumbersResultSet.next()) {
			phoneNumber.add(mapPhoneNumber(phoneNumberConnection, phoneNumbersResultSet));
		}
		return phoneNumber;
	}
	
//Detail of Email Address by Contact ID	
	
	public static List<EmailAddress> GetEmailAddressDetail(String id) throws Exception {
		Connection emailAddressConnection = getConnection();
		Statement emailAddressStatement = emailAddressConnection.createStatement();
		String emailAddressQuery = "SELECT * FROM " + emailAddressTable + " WHERE contactID = " + id;
		ResultSet emailAddressResultSet = emailAddressStatement.executeQuery(emailAddressQuery);				
		List<EmailAddress> emailAddressDetail = new ArrayList<EmailAddress>();
		while (emailAddressResultSet.next()) {
			emailAddressDetail.add(mapEmailAddress(emailAddressConnection, emailAddressResultSet));
		}
		return emailAddressDetail;
	}

//Detail of Email Address by ID of Email Address
	
	public static List<EmailAddress> GetEmailAddress(String id) throws Exception {
		Connection emailAddressConnection = getConnection();
		Statement emailAddressStatement = emailAddressConnection.createStatement();
		String emailAddressQuery = "SELECT * FROM " + emailAddressTable + " WHERE id = " + id;
		ResultSet emailAddressResultSet = emailAddressStatement.executeQuery(emailAddressQuery);				
		List<EmailAddress> emailAddress = new ArrayList<EmailAddress>();
		while (emailAddressResultSet.next()) {
			emailAddress.add(mapEmailAddress(emailAddressConnection, emailAddressResultSet));
		}
		return emailAddress;
	}
	
//Detail of Employer by Contact ID		
	
	public static List<Employer> GetEmployerDetail(String id) throws Exception {
		Connection employerConnection = getConnection();
		Statement employerStatement = employerConnection.createStatement();
		String employerQuery = "SELECT * FROM " + employerTable + " WHERE contactID = " + id;
		ResultSet employerResultSet = employerStatement.executeQuery(employerQuery);				
		List<Employer> employerDetail = new ArrayList<Employer>();
		while (employerResultSet.next()) {
			employerDetail.add(mapEmployer(employerConnection, employerResultSet));
		}
		return employerDetail;
	}
	
//Detail of Employer by ID of employer
	
	public static List<Employer> GetEmployer(String id) throws Exception {
		Connection employerConnection = getConnection();
		Statement employerStatement = employerConnection.createStatement();
		String employerQuery = "SELECT * FROM " + employerTable + " WHERE id = " + id;
		ResultSet employerResultSet = employerStatement.executeQuery(employerQuery);				
		List<Employer> employer = new ArrayList<Employer>();
		while (employerResultSet.next()) {
			employer.add(mapEmployer(employerConnection, employerResultSet));
		}
		return employer;
	}
	//Map Contact	
		protected static Contact mapContact(Connection connection, ResultSet resultSet) throws SQLException {


			int id = resultSet.getInt("id");

			String firstName = resultSet.getString("firstname");		
			String middleName = resultSet.getString("middlename");
			String lastName = resultSet.getString("lastname");	
			return new Contact(id, firstName, middleName, lastName);
		}
		
//Map Address	
		protected static Address mapAddress(Connection connection, ResultSet resultSet) throws SQLException {

				int id = resultSet.getInt("id");
				int contactID = resultSet.getInt("contactID");
				
				String streetAddress = resultSet.getString("streetAddress");
				String state = resultSet.getString("state");
				int zipCode = resultSet.getInt("zipCode");
				
				return new Address(id, contactID, streetAddress, state, zipCode);
			}
		
	//Map Phone Number	
		protected static PhoneNumber mapPhoneNumber(Connection connection, ResultSet resultSet) throws SQLException {

			int id = resultSet.getInt("id");
			int contactID = resultSet.getInt("contactID");
			
			int areaCode = resultSet.getInt("areaCode");
			int exchange = resultSet.getInt("exchange");
			int extension = resultSet.getInt("extension");
			
			return new PhoneNumber(id, contactID, areaCode, exchange, extension);
		}
		
	//Map Email Address	
		protected static EmailAddress mapEmailAddress(Connection connection, ResultSet resultSet) throws SQLException {

			int id = resultSet.getInt("id");
			int contactID = resultSet.getInt("contactID");
			
			String EmailAddress = resultSet.getString("EmailAddress");
			
			return new EmailAddress(id, contactID, EmailAddress);
		}

	//Map Employer	
		protected static Employer mapEmployer(Connection connection, ResultSet resultSet) throws SQLException {


			int id = resultSet.getInt("id");
			int contactID = resultSet.getInt("contactID");

			String companyName = resultSet.getString("companyName");		
			String streetAddress = resultSet.getString("streetAddress");
			String state = resultSet.getString("state");
			int zipCode = resultSet.getInt("zipCode");
			
			return new Employer(id, contactID, companyName, streetAddress, state, zipCode);
		}
	//Database connection
		protected static Connection getConnection() throws Exception {
			try {
				Class.forName(driver);

			} catch(ClassNotFoundException cnfe) {
				System.err.println("Error loading driver: " + cnfe);
			}
			// Establish network connection to database.
			Properties userInfo = new Properties();
			userInfo.put("user", username);
			userInfo.put("password", password);
			Connection connection = DriverManager.getConnection(url, userInfo);
			
			return (connection);
		}
}
