package testData;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.junit.jupiter.api.Test;

import coreservlets.Add;
import coreservlets.Address;
import coreservlets.Contact;
import coreservlets.EmailAddress;
import coreservlets.Employer;
import coreservlets.Get;
import coreservlets.PhoneNumber;
import coreservlets.Validation;

public class UnitTesting {
	
	String testLetterNumberCombo = "ABC123";
	String Zach = "Zach";
	String George = "George";
	String Dorow = "Dorow";
	String streetAddress = "1888 streetAddress";
	String state = "WI";
	String zipCode = "54703";
	String threeNumbers = "123";
	String fourNumbers = "1234";
	String emailAddress = "zdorow@me.com";
	String badEmailAddress = "zdorow@me.c";
	String companyName = "Fake Name";
	String testNull = null;
	
	int zip = 54703;
	int threeNum = 123;
	int fourNum = 1234; 
	
	
@Test
public void testValidation()
	{	
	
	assertTrue(Validation.isContactValid(Zach,  George, Dorow));
	assertTrue(Validation.isAddressValid(streetAddress, state, zipCode));
	assertTrue(Validation.isPhoneNumberValid(threeNumbers, threeNumbers, fourNumbers));
	assertTrue(Validation.isEmailAddressValid(emailAddress));
	assertTrue(Validation.isEmployerValid(companyName, streetAddress, state, zipCode));
	assertTrue(Validation.isAllNumbers(threeNumbers));
	
	assertFalse(Validation.isContactValid(Zach,  testNull, Dorow));
	assertFalse(Validation.isAddressValid(streetAddress, state, testLetterNumberCombo));
	assertFalse(Validation.isPhoneNumberValid(threeNumbers, fourNumbers, fourNumbers));
	assertFalse(Validation.isEmailAddressValid(badEmailAddress));
	assertFalse(Validation.isEmployerValid(companyName, streetAddress, state, testLetterNumberCombo));
	assertFalse(Validation.isAllNumbers(testLetterNumberCombo));
	
	}

//Testing Bean Classes since I could not seem to be able to test the 
//  Add, Edit and Delete Classes they could not talk to the database for whatever reason 
@Test
public void testBeanClasses() throws Exception {
	
	Contact Contact = new Contact(111, "Larry", "Gary", "Ellison");
	assertAll("Conact",
			() -> assertEquals(111, Contact.getId()),
			() -> assertEquals("Larry", Contact.getFirstName()),
			() -> assertEquals("Gary", Contact.getMiddleName()),
			() -> assertEquals("Ellison", Contact.getLastName())
			); 
	
	Address Address = new Address(1, 111, "123 Main Street", "WI", 12345);
	assertAll("Address",
			() -> assertEquals(1, Address.getId()),
			() -> assertEquals(111, Address.getContactID()),
			() -> assertEquals("123 Main Street", Address.getStreetAddress()),
			() -> assertEquals("WI", Address.getState()),
			() -> assertEquals(12345, Address.getZipCode())
			); 
	
	PhoneNumber PhoneNumber = new PhoneNumber(1,111,876,543,2100);
	assertAll("PhoneNumber",
			() -> assertEquals(1, PhoneNumber.getId()),
			() -> assertEquals(111, PhoneNumber.getContactID()),
			() -> assertEquals(876, PhoneNumber.getAreaCode()),
			() -> assertEquals(543, PhoneNumber.getExchange()),
			() -> assertEquals(2100, PhoneNumber.getExtension())
			); 
	
	EmailAddress EmailAddress = new EmailAddress(1, 111, "Larry@gmail.com");
	assertAll("EmailAddress",
			() -> assertEquals(1, EmailAddress.getId()),
			() -> assertEquals(111, EmailAddress.getContactID()),
			() -> assertEquals("Larry@gmail.com", EmailAddress.getEmailAddress())
			);
	
	Employer Employer = new Employer(1, 111, "Quiznos", "224 Second Street", "WI", 12345);
	assertAll("Employer",
			() -> assertEquals(1, Employer.getId()),
			() -> assertEquals(111, Employer.getContactID()),
			() -> assertEquals("Quiznos", Employer.getCompanyName()),
			() -> assertEquals("224 Second Street", Employer.getStreetAddress()),
			() -> assertEquals("WI", Employer.getState()),
			() -> assertEquals(12345, Employer.getZipCode())
			); 
	}

}

